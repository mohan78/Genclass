Genclass
A python module for generating create classes. Just give the class name and its fields to generate the block of class code right in that file.